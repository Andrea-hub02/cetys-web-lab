// pages/headerPage.tsx

import React from 'react';
import Header from './header';

const HeaderPage = () => {
    return (
        <div>
            <Header />
        </div>
    );
}

export default HeaderPage;
